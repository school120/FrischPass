(function(){
  const wv = document.getElementById('wv');
  const logEl = document.getElementById('log');
  const ipEl = document.getElementById('ip');
  const lenEl = document.getElementById('len');
  const csvEl = document.getElementById('csv');
  const dpiEl = document.getElementById('dpi');
  const modeEl = document.getElementById('mode');
  const saveBtn = document.getElementById('save');
  const canvas = document.getElementById('preview');
  const ctx = canvas.getContext('2d');

  function log(s){ logEl.textContent += s + "\\n"; logEl.scrollTop = logEl.scrollHeight; }

  // persist settings
  chrome.storage.local.get(['printerIP','labelLen','csvUrl','dpi','mode'], (st) => {
    if (st.printerIP) ipEl.value = st.printerIP;
    if (st.labelLen) lenEl.value = st.labelLen;
    if (st.csvUrl) csvEl.value = st.csvUrl;
    if (st.dpi) dpiEl.value = st.dpi;
    if (st.mode) modeEl.value = st.mode;
  });
  saveBtn.onclick = () => {
    chrome.storage.local.set({ printerIP: ipEl.value.trim(), labelLen: parseInt(lenEl.value,10)||90, csvUrl: csvEl.value.trim(), dpi: parseInt(dpiEl.value,10)||300, mode: modeEl.value });
    log("✔ Settings saved");
  };

  // Roster
  const roster = new Map();
  async function loadRoster(url){
    try{
      const res = await fetch(url, {cache:'no-store'});
      const txt = await res.text();
      const rows = parseCSV(txt).filter(r => r.length && r.join('').trim()!==''); const h = rows[0].map(x=>x.trim().toLowerCase());
      const iId=h.indexOf('legacy student id'), iName=h.indexOf('full name'), iGrade=h.indexOf('current grade');
      for(let k=1;k<rows.length;k++){ const rr = rows[k]; const id=(rr[iId]||'').trim(); if(id) roster.set(id,{name:(rr[iName]||'').trim(), grade:(rr[iGrade]||'').trim()}); }
      log("Roster loaded: " + roster.size);
    }catch(e){ log("Roster load error: "+e); }
  }
  loadRoster(csvEl.value);

  function parseCSV(t){const r=[];let i=0,c='',row=[],q=false;while(i<t.length){const ch=t[i];if(q){if(ch=='\"'){if(t[i+1]=='\"'){c+='\"';i++;}else q=false;}else c+=ch;} else {if(ch=='\"') q=true; else if(ch==","){row.push(c);c='';} else if(ch=="\\n"){row.push(c);r.push(row);row=[];c='';} else if(ch=="\\r"){} else c+=ch;} i++;} if(c.length||row.length){row.push(c);r.push(row);} return r;}

  // Canvas label render (62mm width -> ~696 dots @300dpi; length based on mm)
  function mmToDots(mm, dpi){ return Math.round(mm/25.4*dpi); }
  function ensureCanvas(lenMM, dpi){
    const widthDots = 696; // Brother printable width for 62mm (approx/safe)
    const heightDots = mmToDots(lenMM, dpi);
    canvas.width = widthDots;
    canvas.height = heightDots;
    ctx.fillStyle="#fff"; ctx.fillRect(0,0,canvas.width,canvas.height);
    return {widthDots, heightDots};
  }
  function renderLabel({name, grade, timestamp}, lenMM, dpi){
    const {widthDots, heightDots} = ensureCanvas(lenMM, dpi);
    ctx.fillStyle="#000";
    ctx.font = "bold " + Math.floor(0.24*25.4/25.4*dpi) + "px Arial"; // ~6mm
    ctx.fillText("FRISCHPASS – EARLY DISMISSAL", 10, Math.floor(8/25.4*dpi*10)); // rough position

    ctx.font = "bold " + Math.floor(0.2*dpi) + "px Arial";
    ctx.fillText(name||"Unknown Student", 10, Math.floor(16/25.4*dpi*10));

    ctx.font = Math.floor(0.18*dpi) + "px Arial";
    ctx.fillText("Grade: " + (grade||""), 10, Math.floor(22/25.4*dpi*10));

    ctx.font = Math.floor(0.18*dpi) + "px Arial";
    ctx.fillText("Signed out: " + timestamp, 10, Math.floor(30/25.4*dpi*10));

    return {widthDots, heightDots};
  }

  function dither1bit(){
    const img = ctx.getImageData(0,0,canvas.width,canvas.height);
    const data = img.data;
    const out = new Uint8Array(((canvas.width+7)>>3) * canvas.height);
    let p=0;
    for (let y=0; y<canvas.height; y++){
      for (let x=0; x<canvas.width; x+=8){
        let byte = 0;
        for (let b=0; b<8; b++){
          const xx = x+b;
          if (xx >= canvas.width) { byte <<= (8-b); break; }
          const i = (y*canvas.width + xx)*4;
          const lum = (data[i]*0.299 + data[i+1]*0.587 + data[i+2]*0.114);
          byte = (byte<<1) | (lum < 128 ? 1 : 0); // 1 = black
        }
        out[p++] = byte;
      }
    }
    return out;
  }

  // Brother Raster skeleton — PLEASE set printer Command Mode = Raster for this branch
  function buildBrotherRaster(widthDots, heightDots, packed){
    const bytes = [];
    function push(){ for (let i=0;i<arguments.length;i++) bytes.push(arguments[i]); }
    function pushLE16(n){ bytes.push(n & 0xFF, (n>>8)&0xFF); }

    // !!! This sequence may need tuning per Brother Raster Command Reference.
    // Init
    push(0x1B,0x40);           // ESC @ (reset)
    push(0x1B,0x69,0x61,0x01); // ESC i a 01 : Raster mode
    push(0x1B,0x69,0x7A,0x00); // ESC i z 00 : No compression
    // Set media? (often not required for continuous roll if auto-detect is on)
    // Margin (top) 0
    push(0x1B,0x69,0x64,0x00,0x00); // ESC i d nL nH (top margin lines=0) – may be ignored

    const bytesPerLine = (widthDots + 7) >> 3;

    // Send each raster line
    let p = 0;
    for (let y=0; y<heightDots; y++){
      push(0x67, 0x00); // 'g' 00 : raster line, no compression (some models require 0x1B 0x2A?)
      pushLE16(bytesPerLine);
      for (let i=0;i<bytesPerLine;i++) bytes.push(packed[p++]);
    }

    // Print & cut
    push(0x0C); // FF : print and feed (page end). On QL, should trigger print/cut with auto-cut.
    return new Uint8Array(bytes);
  }

  // ESC/P text feed fallback — set printer Command Mode = ESC/P for this branch
  function buildEscpText({name, grade, timestamp}, lenMM){
    const arr = [];
    function push(){ for (let i=0;i<arguments.length;i++) arr.push(arguments[i]); }
    function text(str){ for(let i=0;i<str.length;i++){ arr.push(str.charCodeAt(i)&0xFF); } }
    push(0x1B,0x40); // ESC @ reset
    text("\\n\\nFRISCHPASS\\n" + (name||"Unknown Student") + "\\n" + (grade||"") + "\\n" + timestamp + "\\n\\n");
    push(0x0C); // Form feed
    return new Uint8Array(arr);
  }

  // Inject observer into the Veracross webview
  function injectObserver() {
    chrome.storage.local.get(['csvUrl'], (st) => {
      const csvUrl = st.csvUrl || csvEl.value.trim();
      const code = `
        (function(){
          const roster = new Map();
          function parseCSV(t){const r=[];let i=0,c='',row=[],q=false;while(i<t.length){const ch=t[i];if(q){if(ch=='"'){if(t[i+1]=='"'){c+='"';i++;}else q=false;}else c+=ch;} else {if(ch=='"') q=true; else if(ch==","){row.push(c);c='';} else if(ch=="\\n"){row.push(c);r.push(row);row=[];c='';} else if(ch=="\\r"){} else c+=ch;} i++;} if(c.length||row.length){row.push(c);r.push(row);} return r;}
          async function loadRoster(url){
            try{const res=await fetch(url,{cache:'no-store'});const txt=await res.text();const rows=parseCSV(txt).filter(r=>r.length&&r.join('').trim()!=='');const h=rows[0].map(x=>x.trim().toLowerCase());const iId=h.indexOf('legacy student id'), iName=h.indexOf('full name'), iGrade=h.indexOf('current grade'); for(let k=1;k<rows.length;k++){const rr=rows[k];const id=(rr[iId]||'').trim(); if(id) roster.set(id,{name:(rr[iName]||'').trim(), grade:(rr[iGrade]||'').trim()});} }
            catch(e){}
          }
          loadRoster(${JSON.stringify(csvUrl)});
          const input = document.getElementById('legacy_id');
          const container = document.querySelector('#checkin_response');
          function success(){
            const id = (input && input.value||'').trim();
            const info = id ? (roster.get(id)||{name:'Unknown Student', grade:''}) : {name:'Unknown Student', grade:''};
            window.postMessage({ type:'vc_success', id, info }, '*');
            setTimeout(()=>{ if(input){input.value=''; input.focus();}}, 100);
          }
          if(container){
            const obs = new MutationObserver(()=>{
              const s = container.querySelector('.success');
              if(s && getComputedStyle(s).display!=='none'){ success(); }
            });
            obs.observe(container,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
          }
        })();
      `;
      wv.executeScript({ code }, () => {
        if (chrome.runtime.lastError) log("Inject error: " + chrome.runtime.lastError.message);
        else log("✔ Observer injected");
      });
    });
  }

  wv.addEventListener('contentload', injectObserver);

  // Bridge from webview -> app
  window.addEventListener('message', (e) => {
    if (!e.data || e.data.type!=='vc_success') return;
    const len = parseInt(lenEl.value,10)||90;
    const dpi = parseInt(dpiEl.value,10)||300;
    const info = e.data.info || {name:'Unknown Student', grade:''};
    const job = { name: info.name, grade: info.grade, timestamp: new Date().toLocaleString() };

    // Render to canvas
    const geom = renderLabel(job, len, dpi);
    const packed = dither1bit();

    // Build bytes depending on mode
    const mode = modeEl.value;
    let bytes;
    if (mode === 'raster') {
      bytes = buildBrotherRaster(geom.widthDots, geom.heightDots, packed);
      log("Raster job: " + geom.widthDots + "x" + geom.heightDots + " → " + bytes.byteLength + " bytes");
    } else {
      bytes = buildEscpText(job, len);
      log("ESC/P feed job → " + bytes.byteLength + " bytes");
    }

    // Send to printer
    const ip = ipEl.value.trim();
    sendToPrinter(ip, bytes);
  });

  function sendToPrinter(ip, bytes){
    chrome.sockets.tcp.create({}, (createInfo) => {
      const sid = createInfo.socketId;
      chrome.sockets.tcp.connect(sid, ip, 9100, (res) => {
        if (res < 0) { log("Connect error: " + chrome.runtime.lastError?.message); chrome.sockets.tcp.close(sid); return; }
        chrome.sockets.tcp.send(sid, bytes.buffer, (sendInfo) => {
          if (sendInfo.resultCode < 0) log("Send error: " + sendInfo.resultCode);
          chrome.sockets.tcp.close(sid);
          log("✔ Sent " + bytes.byteLength + " bytes to " + ip + ":9100");
        });
      });
    });
  }
})();