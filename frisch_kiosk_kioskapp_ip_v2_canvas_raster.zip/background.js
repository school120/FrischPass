
chrome.app.runtime.onLaunched.addListener(function() {
  chrome.app.window.create('main.html', {
    id: 'frisch-kiosk',
    innerBounds: { width: 1100, height: 780 }
  });
});
